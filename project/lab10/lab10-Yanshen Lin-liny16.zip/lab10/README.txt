Lab 10: PHP

Name: < Yanshen Lin >

Method/styles/tech: 
	-I also finished the extra creait for add a new tap to show the movie name and 
their corresponding actors.
	-The csv file is located in folder file.
	-I also add the movie-delete.php file.
	-The whole database has been export to iit.sql

